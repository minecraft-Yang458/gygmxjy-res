ServerEvents.recipes(event => {
event.smelting(
  Item.of('minecraft:leather', 1), 
  [
    'minecraft:rotten_flesh'
  ]
).xp(1).cookingTime(600)
event.smelting('create:brass_ingot','minecraft:copper_ingot',0.01,72000)
})